<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\Admin\AdminController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/login',[LoginController::class,'index'])->name('login')->middleware('guest');
Route::post('/login',[LoginController::class,'login']);

Route::get('/',[AdminController::class,'index'])->middleware('auth');
Route::get('/dtkriteria',[AdminController::class,'dtkriteria'])->middleware('auth');

//data mahasiswa
Route::get('/dtmahasiswa',[AdminController::class,'dtmahasiswa'])->middleware('auth');
Route::post('/importdata',[AdminController::class,'importdata'])->middleware('auth');

Route::get('/resetmahasiswa',[AdminController::class,'resetmahasiswa'])->middleware('auth');

Route::get('/dtraining',[AdminController::class,'dtraining'])->middleware('auth');
Route::match(['get','post'],'/addtraining',[AdminController::class,'addtraining'])->middleware('auth');
Route::get('/edtraining/{datamhs:id}',[AdminController::class,'edtraining'])->middleware('auth');
Route::post('/updatetrn',[AdminController::class,'updatetrn'])->middleware('auth');
Route::get('/deltraining/{datamhs:id}',[AdminController::class,'deltraining'])->middleware('auth');

Route::get('/dtuji',[AdminController::class,'dtuji'])->middleware('auth');
Route::match(['get','post'],'/adduji',[AdminController::class,'adduji'])->middleware('auth');
Route::get('/edtuji/{datamhs:id}',[AdminController::class,'edtuji'])->middleware('auth');
Route::post('/updateuji',[AdminController::class,'updateuji'])->middleware('auth');
Route::get('/deluji/{datamhs:id}',[AdminController::class,'deluji'])->middleware('auth');

Route::get('/prsdata',[AdminController::class,'prsdata'])->middleware('auth');
Route::get('/mulaiprs',[AdminController::class,'mulaiprs'])->middleware('auth');

Route::get('/datahasil',[AdminController::class,'datahasil'])->middleware('auth');

Route::get('/logout',[AdminController::class,'logout'])->middleware('auth');