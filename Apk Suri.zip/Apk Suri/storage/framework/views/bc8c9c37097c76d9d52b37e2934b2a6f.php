
<?php $__env->startSection('container'); ?>
<div class="app-wrapper">
            <div class="app-content pt-3 p-md-3 p-lg-4">
                <div class="container-xl">
                    <h1 class="app-page-title"><?php echo e($title); ?></h1>
                    <div class="row">
                    	<div class="col md-12 text-center mb-2">
                    		<h1><strong>SELAMAT DATANG DI WEBSITE</strong></h1>
                            <h1><strong>ANALISIS DATA KEPUASAN MAHASISWA TERHADAP SARANA DAN PRASARANA DENGAN MENGGUNAKAN ALGORITMA NAÏVE BAYES PADA UNIVERSITAS MUHAMMADIYAH MAKASSAR</strong></h1>
                    	</div>
                    </div>
                    <div class="row g-4 mb-4">
                        <div class="col-6 col-lg-6">
                            <div class="app-card app-card-stat shadow-sm h-100">
                                <div class="app-card-body p-3 p-lg-4">
                                    <h4 class="stats-type mb-1">Data Kriteria</h4>
                                    <div class="stats-figure"><?php echo e($kriteria); ?></div>
                                </div>
                                <a class="app-card-link-mask" href="/dtkriteria"></a>
                            </div>
                        </div>
                        <div class="col-6 col-lg-6">
                            <div class="app-card app-card-stat shadow-sm h-100">
                                <div class="app-card-body p-3 p-lg-4">
                                    <h4 class="stats-type mb-1">Data Mahasiswa</h4>
                                    <div class="stats-figure"><?php echo e($training); ?></div>
                                </div>
                                <a class="app-card-link-mask" href="/dtraining"></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <footer class="app-footer">
                <div class="container text-center py-3">
                    <small class="copyright">NAIVE BAYES CLASSIFICATION</small>
                </div>
            </footer>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tempadmin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\suriapk2\resources\views/admin/index.blade.php ENDPATH**/ ?>