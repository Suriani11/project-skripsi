
<?php $__env->startSection('container'); ?>
<div class="app-wrapper">
    <div class="app-content pt-3 p-md-3 p-lg-4">
        <div class="container-xl">
            <h1 class="app-page-title"><?php echo e($title); ?></h1>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <?php if(Session::has('dtuji')): ?>
                    <?php echo Session::get('dtuji'); ?>

                <?php endif; ?>
                <div class="card">
                    <div class="card-header text-center">
                        <h4 class="card-title"><?php echo e($title); ?></h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="example" class="table table-striped" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama</th>
                                        <th>Tangibles</th>
                                        <th>Reliability</th>
                                        <th>Responsiveness</th>
                                        <th>Assurance</th>
                                        <th>Empathy</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $uji; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($nodf++); ?></td>
                                        <td><?php echo e($tr->nama); ?></td>
                                        <td><?php echo e($tr->k1); ?></td>
                                        <td><?php echo e($tr->k2); ?></td>
                                        <td><?php echo e($tr->k3); ?></td>
                                        <td><?php echo e($tr->k4); ?></td>
                                        <td><?php echo e($tr->k5); ?></td>
                                        <td>
                                            <a href="/edtuji/<?php echo e($tr->id); ?>" class="btn btn-info">Edit</a> <a href="/deluji/<?php echo e($tr->id); ?>" class="btn btn-danger" onclick="return confirm('Delete data Uji...?')">Delete</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                        <div class="text-center">
                            <a href="/adduji" class="btn btn-primary">Tambah Data Uji</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <footer class="app-footer">
        <div class="container text-center py-3">
            <small class="copyright">NAIVE BAYES CLASSIFICATION</small>
        </div>
    </footer>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tempadmin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\suriapk\resources\views/admin/data-uji.blade.php ENDPATH**/ ?>