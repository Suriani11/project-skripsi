
<?php $__env->startSection('container'); ?>
<div class="app-wrapper">
    <div class="app-content pt-3 p-md-3 p-lg-4">
        <div class="container-xl">
            <h1 class="app-page-title"><?php echo e($title); ?></h1>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header text-center">
                        <h4 class="card-title"><?php echo e($title); ?></h4>
                    </div>
                    <div class="card-body">
                        <form action="/adduji" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group mb-3">
                                <label>Nama</label>
                                <input type="text" class="form-control" id="nama" name="nama" placeholder="Input nama" required>
                            </div>
                            <div class="form-group mb-3">
                                <label>Tangibles [Bukti Langsung]</label>
                                <select class="form-select" id="k1" name="k1" required>
                                <option value="">Pilih Keterangan</option>
                                <option value="Lengkap">Lengkap</option>
                                <option value="Cukup Lengkap">Cukup Lengkap</option>
                                <option value="Tidak Lengkap">Tidak Lengkap</option>
                                </select>
                            </div>
                            <div class="form-group mb-3">
                                <label>Reliability [Kehandalan]</label>
                                <select class="form-select" id="k2" name="k2" required>
                                <option value="">Pilih Keterangan</option>
                                <option value="Sangat Memuaskan">Sangat Memuaskan</option>
                                <option value="Memuaskan">Memuaskan</option>
                                <option value="Cukup Memuaskan">Cukup Memuaskan</option>
                                <option value="Tidak Memuaskan">Tidak Memuaskan</option>
                                </select>
                            </div>
                            <div class="form-group mb-3">
                                <label>Responsiveness [Responsivitas]</label>
                                <select class="form-select" id="k3" name="k3" required>
                                <option value="">Pilih Keterangan</option>
                                <option value="Sangat Membantu">Sangat Membantu</option>
                                <option value="Membantu">Membantu</option>
                                <option value="Cukup Membantu">Cukup Membantu</option>
                                <option value="Tidak Membantu">Tidak Membantu</option>
                                </select>
                            </div>
                            <div class="form-group mb-3">
                                <label>Assurance [Jaminan]</label>
                                <select class="form-select" id="k4" name="k4" required>
                                <option value="">Pilih Keterangan</option>
                                <option value="Sangat Baik">Sangat Baik</option>
                                <option value="Baik">Baik</option>
                                <option value="Cukup Baik">Cukup Baik</option>
                                <option value="Tidak Baik">Tidak Baik</option>
                                </select>
                            </div>
                            <div class="form-group mb-3">
                                <label>Empathy [Empati]</label>
                                <select class="form-select" id="k5" name="k5" required>
                                <option value="">Pilih Keterangan</option>
                                <option value="Sangat Baik">Sangat Baik</option>
                                <option value="Baik">Baik</option>
                                <option value="Cukup Baik">Cukup Baik</option>
                                <option value="Tidak Baik">Tidak Baik</option>
                                </select>
                            </div>
                            <div class="text-center mb-4">
                                <button type="submit" class="btn btn-primary">Tambah Data</button>
                                <a href="/dtuji" class="btn btn-info">Kembali</a>    
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <footer class="app-footer">
        <div class="container text-center py-3">
            <small class="copyright">NAIVE BAYES CLASSIFICATION</small>
        </div>
    </footer>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tempadmin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\suriapk\resources\views/admin/add-uji.blade.php ENDPATH**/ ?>