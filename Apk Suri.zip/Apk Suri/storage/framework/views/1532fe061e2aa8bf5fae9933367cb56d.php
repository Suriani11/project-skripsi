
<?php $__env->startSection('container'); ?>
<div class="app-wrapper">
    <div class="app-content pt-3 p-md-3 p-lg-4">
        <div class="container-xl">
            <h1 class="app-page-title"><?php echo e($title); ?></h1>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <?php if(Session::has('datahasil')): ?>
                    <?php echo Session::get('datahasil'); ?>

                <?php endif; ?>
                <div class="card">
                    <div class="card-header text-center">
                        <h4 class="card-title"><?php echo e($title); ?></h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="example" class="table table-striped" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>kategori</th>
                                        <th>tahun_akademik</th>
                                        <th>nim</th>
                                        <th>saran</th>
                                        <th>nidn</th>
                                        <th>kode_matakuliah</th>
                                        <th>status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ktr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($ktr->status!=null): ?>
                                    <tr>
                                        <td><?php echo e($nodf++); ?></td>
                                        <td><?php echo e($ktr->kategori); ?></td>
                                        <td><?php echo e($ktr->tahun_akademik); ?></td>
                                        <td><?php echo e($ktr->nim); ?></td>
                                        <td><?php echo e($ktr->saran); ?></td>
                                        <td><?php echo e($ktr->nidn); ?></td>
                                        <td><?php echo e($ktr->kode_matakuliah); ?></td>
                                        <td>
                                            <?php if($ktr->status=='Puas'): ?>
                                            <span class="btn btn-success">Puas</span>
                                            <?php else: ?>
                                            <span class="btn btn-danger">Tidak Puas</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                    </div>
                </div>
                <br>
                <div class="card">
                    <div class="card-header text-center">
                        <h4 class="card-title">Confusion Matriks (Gabungan Data Training & Data Uji)</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="example" class="table table-striped" style="width:100%">
                                <thead>
                                    <tr>
                                        <th></th>
                                        <th>Aktual Positif</th>
                                        <th>Aktual Negatif</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Prediksi Positif</td>
                                        <td><?php echo e($prpositif->true_positif); ?> (True Positif)</td>
                                        <td><?php echo e($prpositif->false_positif); ?> (False Positif)</td>
                                    </tr>
                                    <tr>
                                        <td>Prediksi Negatif</td>
                                        <td><?php echo e($prnegatif->false_negatif); ?> (False Negatif)</td>
                                        <td><?php echo e($prnegatif->true_negatif); ?> (True Negatif)</td>
                                    </tr>
                            </table>
                        </div>
                        <h4>Dengan Nilai :</h4>
                        <h4>Akurasi : <?php echo e(floor(($prpositif->true_positif+$prnegatif->true_negatif)/($prpositif->true_positif+$prnegatif->true_negatif+$prpositif->false_positif+$prnegatif->false_negatif)*100)); ?>%</h4>
                        <h4>Presisi : <?php echo e(floor($prpositif->true_positif/($prpositif->true_positif+$prpositif->false_positif)*100)); ?>%</h4>
                        <h4>Recall : <?php echo e(floor($prpositif->true_positif/($prpositif->true_positif+$prnegatif->false_negatif)*100)); ?>%</h4>
                        <h4>F1 Score : <?php echo e(floor(2*(($prpositif->true_positif/($prpositif->true_positif+$prpositif->false_positif))*($prpositif->true_positif/($prpositif->true_positif+$prnegatif->false_negatif))/(($prpositif->true_positif/($prpositif->true_positif+$prpositif->false_positif))+($prpositif->true_positif/($prpositif->true_positif+$prnegatif->false_negatif))))*100)); ?>%</h4>
                        <h4>Mahasiwa yang Puas : <?php echo e(round($jumpuas/$jumdatauji*100)); ?>%</h4>
                        <h4>Mahasiwa yang Tidak Puas : <?php echo e(round($jumtdkpuas/$jumdatauji*100)); ?>%</h4>
                        <?php if((round($jumpuas/$jumdatauji*100)>(round($jumtdkpuas/$jumdatauji*100)))): ?>
                        <h4>Rekomendasi : Semoga Pihak Kampus Tetap Mempertahankan kualitas dari saran dan prasana kampus. adapun untuk pelayanan agar tetap memberikan reponsivitas agar mahasiswa merasa nyaman dan lancar melakukan urusan berkasnya</h4>
                        <?php else: ?>
                        <h4>Rekomendasi : Ada baiknya pihak kampus segera melakukan pembenahan dan perbaikan pada fasilitas saran dan prasana yang ada pada kampus</h4>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <footer class="app-footer">
        <div class="container text-center py-3">
            <small class="copyright">NAIVE BAYES CLASSIFICATION</small>
        </div>
    </footer>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tempadmin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\suriapk2\resources\views/admin/data-hasil.blade.php ENDPATH**/ ?>