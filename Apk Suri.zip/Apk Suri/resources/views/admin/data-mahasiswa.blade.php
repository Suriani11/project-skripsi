@extends('tempadmin.main')
@section('container')
<div class="app-wrapper">
    <div class="app-content pt-3 p-md-3 p-lg-4">
        <div class="container-xl">
            <h1 class="app-page-title">{{$title}} @if(count($mahasiswa)>1) <a href="/resetmahasiswa" class="btn btn-danger" onclick="return confirm('Reset Data Mahasiswa...?')">Reset Data Mahasiswa</a> @endif</h1>
        </div>
        <div class="row">
            <div class="col-sm-12">
                @if(Session::has('dtmahasiswa'))
                {!!Session::get('dtmahasiswa')!!}
                @endif
                <div class="card">
                    <div class="card-header text-center">
                        <h4 class="card-title">{{$title}}</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="example" class="table table-striped" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>kategori</th>
                                        <th>tahun_akademik</th>
                                        <th>nim</th>
                                        <th>saran</th>
                                        <th>nidn</th>
                                        <th>kode_matakuliah</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($mahasiswa as $ktr)
                                    <tr>
                                        <td>{{$nodf++}}</td>
                                        <td>{{$ktr->kategori}}</td>
                                        <td>{{$ktr->tahun_akademik}}</td>
                                        <td>{{$ktr->nim}}</td>
                                        <td>{{$ktr->saran}}</td>
                                        <td>{{$ktr->nidn}}</td>
                                        <td>{{$ktr->kode_matakuliah}}</td>
                                    </tr>
                                    @endforeach
                            </table>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header text-center">
                        <h4 class="card-title">{{$title}}</h4>
                    </div>
                    <div class="card-body">
                        <form action="/importdata" method="post" enctype="multipart/form-data">
                            @csrf
                            <div class="form-group mb-3">
                                <label><strong>Import Data Mahasiswa (excel)</strong></label><br><br>
                                <input type="file" class="form-control" id="nama" name="file" placeholder="Input Data mahasiswa (excel)" required>
                            </div>
                            <div class="text-center mb-4">
                                <button type="submit" class="btn btn-primary" onclick="return confirm('Import Data Mahasiswa...?')">Import Data</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <footer class="app-footer">
        <div class="container text-center py-3">
            <small class="copyright">NAIVE BAYES CLASSIFICATION</small>
        </div>
    </footer>
</div>
@endsection
