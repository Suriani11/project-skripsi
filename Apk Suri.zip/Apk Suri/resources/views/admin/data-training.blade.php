@extends('tempadmin.main')
@section('container')
<div class="app-wrapper">
    <div class="app-content pt-3 p-md-3 p-lg-4">
        <div class="container-xl">
            <h1 class="app-page-title">{{$title}}</h1>
        </div>
        <div class="row">
            <div class="col-sm-12">
                @if(Session::has('dtraining'))
                    {!!Session::get('dtraining')!!}
                @endif
                <div class="card">
                    <div class="card-header text-center">
                        <h4 class="card-title">{{$title}}</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="example" class="table table-striped" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama</th>
                                        <th>Tangibles</th>
                                        <th>Reliability</th>
                                        <th>Responsiveness</th>
                                        <th>Assurance</th>
                                        <th>Empathy</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($training as $tr)
                                    <tr>
                                        <td>{{$nodf++}}</td>
                                        <td>{{$tr->nama}}</td>
                                        <td>{{$tr->k1}}</td>
                                        <td>{{$tr->k2}}</td>
                                        <td>{{$tr->k3}}</td>
                                        <td>{{$tr->k4}}</td>
                                        <td>{{$tr->k5}}</td>
                                        <td>
                                            @if($tr->status=='Puas')
                                            <span class="btn btn-success">Puas</span>
                                            @else
                                            <span class="btn btn-warning">Tidak Puas</span>
                                            @endif
                                        </td>
                                        <td>
                                            <a href="/edtraining/{{$tr->id}}" class="btn btn-info">Edit</a> <a href="/deltraining/{{$tr->id}}" class="btn btn-danger" onclick="return confirm('Delete data Training...?')">Delete</a>
                                        </td>
                                    </tr>
                                    @endforeach
                            </table>
                        </div>
                        <div class="text-center">
                            <a href="/addtraining" class="btn btn-primary">Tambah Data Training</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <footer class="app-footer">
        <div class="container text-center py-3">
            <small class="copyright">NAIVE BAYES CLASSIFICATION</small>
        </div>
    </footer>
</div>
@endsection
