<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Datamhs extends Model
{
    use HasFactory;

    protected $fillable = [

        'nama',
        'nim',
        'jenis',
        'k1',
        'k2',
        'k3',
        'k4',
        'k5',
        'status',
    ];
}
