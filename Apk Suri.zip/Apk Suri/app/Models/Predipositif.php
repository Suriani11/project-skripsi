<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Predipositif extends Model
{
    use HasFactory;

    protected $fillable = [

        'true_positif',
        'false_positif',
    ];
}
