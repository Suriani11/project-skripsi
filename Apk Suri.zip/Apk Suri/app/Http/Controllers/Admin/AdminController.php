<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Excel;

//call model
use App\Models\Kriteria;
use App\Models\Datamhs;
use App\Models\Predipositif;
use App\Models\Predinegatif;
use App\Models\Mahasiswa;

//call import
use App\Imports\UserImport;

class AdminController extends Controller
{
    public function index()
    {
        return view('admin.index',[

            'title' => 'Dashboard',
            'active' => 'dashboard',
            'kriteria' => Kriteria::count(),
            'training' => Mahasiswa::count(),
        ]);
    }

    public function dtkriteria()
    {
        return view('admin.data-kriteria',[

            'title' => 'Data Kriteria',
            'active' => 'dtkriteria',
            'kriteria' => Kriteria::all(),
            'nodf' => 1,
        ]);
    }

    public function dtmahasiswa()
    {
        return view('admin.data-mahasiswa',[

            'title' => 'Data Mahasiswa',
            'active' => 'dtmahasiswa',
            'mahasiswa' => Mahasiswa::whereNotNull('status')->get(),
            'nodf' => 1,
        ]);
    }

    public function importdata(Request $request)
    {
        Excel::import(new UserImport(),$request->file('file'));

        return redirect('/dtmahasiswa')->with('dtmahasiswa','<div class="alert alert-success text-center">Data Mahasiswa berhasil di import..!</div>');
    }

    public function resetmahasiswa()
    {
        Mahasiswa::truncate();
        return redirect('/dtmahasiswa')->with('dtmahasiswa','<div class="alert alert-success text-center">Data Mahasiswa berhasil di reset..!</div>');
    }

    public function prsdata()
    {
        return view('admin.proses-data',[

            'title' => 'Proses Data',
            'active' => 'prsdata',
            'mahasiswa' => Mahasiswa::whereNotNull('status')->get(),
            'nodf' => 1,
        ]);
    }

    public function mulaiprs()
    {
        //memulai proses perhitungan
        Predipositif::truncate();
        Predinegatif::truncate();

        //perhitungan confusion matriks
        $getuji2 = Mahasiswa::whereNotNull('status')->get();

        $cnt_true_positif=0;
        $cnt_false_positif=0;
        $cnt_false_negatif=0;
        $cnt_true_negatif=0;

        for ($j=0; $j < count($getuji2); $j++) {

            $ujipuas = Mahasiswa::where('status','Puas')->count()/Mahasiswa::count();

            $ujitidakpuas = Mahasiswa::where('status','Tidak Puas')->count()/Mahasiswa::count();

            $ujiypuas = Mahasiswa::where('status','Puas')->count();
            $ujinpuas = Mahasiswa::where('status','Tidak Puas')->count();

            $ujik1puas = Mahasiswa::where('saran',$getuji2[$j]->saran)->count()/$ujiypuas;
            
            $ujik1tidakpuas = Mahasiswa::where('saran',$getuji2[$j]->saran)->count()/$ujinpuas;
            

            $ujibndpuas = $ujipuas*$ujik1puas;

            $ujibndtidakpuas = $ujitidakpuas*$ujik1tidakpuas;

            $statusuji='';
            

            if ($ujibndpuas>$ujibndtidakpuas) {
                
                $statusuji = 'Puas';

            }else{

                $statusuji = 'Tidak Puas';
            }

            if ($getuji2[$j]->status==$statusuji) {
                
                if ($statusuji=='Puas') {

                    $cnt_false_positif+=1;

                }else{

                    $cnt_true_negatif+=1;
                }

            }else{
                
                if ($statusuji=='Puas') {

                   $cnt_false_negatif+=1; 

                }else{

                    $cnt_true_positif+=1;
                    
                }
            }
        }//batas perulangan for

        $svPredipositif = new Predipositif;
        $svPredipositif->true_positif = $cnt_true_positif;
        $svPredipositif->false_positif = $cnt_false_positif;
        $svPredipositif->save();

        $svPredinegatif = new Predinegatif;
        $svPredinegatif->false_negatif = $cnt_false_negatif;
        $svPredinegatif->true_negatif = $cnt_true_negatif;
        $svPredinegatif->save();

        return redirect('/datahasil')->with('datahasil','<div class="alert alert-success text-center">Proses Perhitungan telah selesai..!</div>');

    }

    public function datahasil()
    {
        return view('admin.data-hasil',[

            'title' => 'Hasil Prediksi',
            'active' => 'datahasil',
            'mahasiswa' => Mahasiswa::whereNotNull('status')->get(),
            'nodf' => 1,
            'prpositif' => Predipositif::latest()->first(),
            'prnegatif' => Predinegatif::latest()->first(),
            'nodf2' => 1,
            'jumdatauji' => Mahasiswa::whereNotNull('status')->count(),
            'jumpuas' => Mahasiswa::where('status','Puas')->count(),
            'jumtdkpuas' => Mahasiswa::where('status','Tidak Puas')->count(),
        ]);
    }

    public function logout()
    {
        Auth::logout();
        request()->session()->invalidate();
        request()->session()->regenerateToken();

        return redirect('/login')->with('login','<div class="alert alert-success text-center">Logout..!</div>');
    }
}
