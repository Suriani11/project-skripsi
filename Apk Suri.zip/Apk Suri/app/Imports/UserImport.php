<?php

namespace App\Imports;

use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;

use App\Models\Mahasiswa;

class UserImport implements ToCollection
{
    /**
    * @param Collection $collection
    */
    public function collection(Collection $collection)
    {

        for ($i=0; $i < count($collection); $i++) { 
            
            if ($i!=0) {


                $data['kategori'] = $collection[$i][0];
                $data['tahun_akademik'] = $collection[$i][1];
                $data['nim'] = $collection[$i][2];
                $data['saran'] = $collection[$i][3];
                $data['nidn'] = $collection[$i][4];
                $data['kode_matakuliah'] = $collection[$i][5];

                $data['saran'] = strtolower($data['saran']);

                if ($data['saran'] == 'terimakasih pak selama proses pembelajaran menyenangkan tapi fasilitas kampus terutama lcd kurang memadai selama proses pembelajaran' ||
                    $data['saran'] == 'semoga lebih baik kedepannya dalam melengkapi fasilitas' ||
                    $data['saran'] == 'fasilitas yang memadai' ||
                    $data['saran'] == 'semoga lebih baik kedepannya dalam melengkapi fasilitas') {
                    
                    $data['status'] = 'Puas';

                }elseif($data['saran'] == 'lebih memperhatikan sarana dan prasarana yang ada agar pada saat proses pembelajaran berlangsung mahasiswa lebih nyaman memakainya' || 
                    $data['saran'] == 'sarana dan prasarana proses pembelajaran belum Memadai' || 
                    $data['saran'] == 'fasilitas pendukung proses belajar mengajar baik secara offline dan online lebih di Maksimalkan lagi' ||
                    $data['saran'] == 'kelas diperbanyak' ||
                    $data['saran'] == 'kuliah lebih diberikan fasilitas yang baik' ||
                    $data['saran'] == 'menciptakan suasana ruang belajar yang nyaman bagi mahasiswa, memperhatikan fasilitas kelas yang perlu diadakan' ||


                    $data['saran'] == 'meningkatkan fasilitas dalam perkuliahan' ||
                    
                    $data['saran'] == 'fasilitas perlu di perhatikan' ||
                    $data['saran'] == 'yang perlu diperhatikan adalah memperadakan dan memperbaiki fasilitas pembelajaran yang lebih baik, mulai dari kursinya, kemudian ketersediaan lcd disetiap kelas, dan perlunya juga ac di ruang kelas' ||
                    $data['saran'] == 'fasilitas kelas diperbaiki' ||
                    $data['saran'] == 'tingkatkan fasilitas kelas' ||
                    $data['saran'] == 'fasilitas kelas perlu ditingkatkan lagi seperti kipas atau ac' ||
                    $data['saran'] == 'fasilitas kampus perlu ditingkatkan agar menambah kenyamanan  mahasiswa dalam proses pembelajaran.' ||
                    $data['saran'] == 'saran saya perbaiki fasilitas kampus, dan mohon setiap toilet dibersihkan dan dijamin airnya mengalir' ||
                    $data['saran'] == 'fasilitas lebih ditingkatkan lagi' ||
                    $data['saran'] == 'fasilitas lebih ditingkatkan' ||
                    $data['saran'] == 'menambah fasilitas kampus' ||
                    $data['saran'] == 'sebaiknya fasilitas-fasilitas yang dibutuhkan dalam perkuliahan segera dilengkapi, terimakasih' ||
                    $data['saran'] == 'menambah fasilitas kampus' ||
                    $data['saran'] == 'semoga kedepannya fasilitasnya dan pelayanannya lebih ditingkatkan lagi menjadi lebih baik' ||
                    $data['saran'] == 'tabe pak/ibu, hendaknya fasilitas ruang perkuliahan diperbaiki lagi. demi kenyamanan dalam proses perkuliahan' ||
                    $data['saran'] == 'semoga fasilitas kampus bisa di perlengkap lagi' ||
                    $data['saran'] == 'semoga fasilitas kampus di perlengkap' ||
                    $data['saran'] == 'kurangnya fasilitas dalam mendukung bissmillah seperti kipas angin, lcd dan alat laboratorium' ||
                    $data['saran'] == 'fasilitas perkuliahan lebih dilengkapi, seperti ac, kipas angin, kelas, akses buku farmasi, lcd dan colokan. juga peralatan lab dilengkapi dan diperbanyak.' ||
                    $data['saran'] == 'sebaiknya dan seharusnya fasilitas belajar dan lab lebih diperhatikan lagi dan dilengkapi,' ||
                    $data['saran'] == 'agar sekiranya fasilitas lebih diperhatikan lagi' ||
                    $data['saran'] == 'harap melengkapi fasilitas yg kurang' ||
                    $data['saran'] == 'menambah fasilitas lab' ||
                    $data['saran'] == 'mohon melengkapi fasilitas yg kurang' ||
                    $data['saran'] == 'agar kiranya fasilitas prodi segera d lengkapi' ||
                    $data['saran'] == 'kurangnya fasilitas' ||
                    $data['saran'] == 'masih kurangnya fasilitas' ||
                    $data['saran'] == 'masih kurangnya fasilitas jurusan' ||
                    $data['saran'] == 'agar fasilitas pembelajaran lebih menunjang dan memadai sehingga terlaksananya perkuliahan dgn baik' ||
                    $data['saran'] == 'menambah fasilitas penunjang pembelajaran sehingga terciptanya pembelajaran yg baik' ||
                    $data['saran'] == 'fasilitas laboratorium di tambah lagi' ||
                    $data['saran'] == 'fasilitas belajar mahasiswa sebaiknya ditingkatkan lagi' ||
                    $data['saran'] == 'fasilitas kampus di perlukan' ||
                    $data['saran'] == 'fasilitas kampus masih diperlukan' ||
                    $data['saran'] == 'mohon fasilitas kelas dan lab di lengkapi' ||
                    $data['saran'] == 'terimakasih pak metode pembelajaran ta alhamdullilah menyenangkan tpi sayang lcd yg di siapkan tidak memadai ' ||
                    $data['saran'] == 'pengadaan alat laboratorium agar lebih menunjang proses praktikum' || 
                    $data['saran'] == 'sarana dan prasarana lebih ditingkatkan dan adakan ac atau setidaknya kipas angin yang cukup di setiap kelas agar tidak merasa kepanasan di dalam kelas' ||
                    $data['saran'] == 'untuk sarana dan prasarana lebih ditingkatkan seperti pengadaan ac dalam ruang kelas agar lebih nyaman dalam proses belajar ' ||
                    $data['saran'] == 'fasilitas kelas dan leb sebaiknya segera di penuhi' ||
                    $data['saran'] == 'fasilitas kelas dan leb semoga segera terpenuhi' ||
                    $data['saran'] == 'menyediakan Fasilitas buku penunjang yang lebih memudahkan mahasiswa' ||
                    $data['saran'] == 'fasilitas kampus semoga di perlengkap lagi' ||
                    $data['saran'] == 'fasilitas kampus semoga di perlengkap lagi' ||
                    $data['saran'] == 'fasilitas ruangan di lengkapi begitupun dengan laboratorium' ||
                    $data['saran'] == 'saya berharap agar fasilitas pada prodi lebih lengkap lagi' ||
                    $data['saran'] == 'tingkatkan fasilitas prodi kebidanan khususnya alat praktikum' ||
                    $data['saran'] == 'fasilitas perlu di maksimalkan kembali' ||
                    $data['saran'] == 'maksimalkan  ketersediaan fasilitas di prodi' ||
                    $data['saran'] == 'maksimalkan fasilitas di prodi' ||
                    $data['saran'] == 'semoga fasilitas proyektor dikelas dapat di perbarui' ||     
                    $data['saran'] == 'mohon untuk diberikan fasilitas yang memadai untuk melakukan perkuliahan secara online' ||
                    $data['saran'] == 'mohon untuk diberikan fasilitas yang memadai untuk melakukan perkuliahan secara online' ||
                    $data['saran'] == 'di lab komputer banyak komputer yang sudah rusak' ||
                    $data['saran'] == 'fasilitas pembelajaran perlu ditingkatkan' ||
                    $data['saran'] == 'perlu meningkatkan sarana dan pra sarana dalam perkuliahan' ||
                    $data['saran'] == 'sarana dan prasarana pembelajaran perlu ditingkatkan' ||
                    $data['saran'] == 'meningkatkan fasilitas dalam perkuliahan' ||
                    $data['saran'] == 'meningkatkan sarana pembelajaran perkuliahan' || 
                    $data['saran'] == 'sarana dan prasarana proses pembelajaran perlu di tingkatkan' || 
                    $data['saran'] == 'agar fasilitas dalam kelas lebih ditingkatkan' ||
                    $data['saran'] == 'lebih meningkatkan fasilitas didalam kelas' ||
                    $data['saran'] == 'agar lebih ditingkatkan lagi Fasilitas didalam kelas' ||
                    $data['saran'] == 'lebih memperhatikan sarana dan prasarana yang ada agar pada saat proses pembelajaran berlangsung mahasiswa lebih nyaman memakainya' ||
                    $data['saran'] == 'lebih memperhatikan sarana dan prasarana agar saat proses pembelajaran berlangsung mahasiswa lebih nyaman' ||
                    $data['saran'] == 'fasilitas pendukung proses belajar mengajar baik secara offline dan online lebih di maksimalkan lagi' ||
                    $data['saran'] == 'lebih memperhatikan sarana dan prasarana agar saat proses pembelajaran berlangsung mahasiswa lebih nyaman' || 
                    $data['saran'] == 'lebih memperhatikan sarana dan prasarana agar terwujuddnya kenyamanan saat proses pembelajaran' || 
                    $data['saran'] == 'lebih memperhatikan sarana dan prasarana agar terwujuddnya kenyamanan saat proses pembelajaran berlangsung ')
                {
                    
                    $data['status'] = 'Tidak Puas';

                }else{

                    $data['status'] = null;
                }

                if ($data['status']!=null) {
                    
                    Mahasiswa::create($data);
                }

            }
        }
    }
}
